# Node.js workway demo

This demo shows CPUs and current memory consumption.

```sh
npm install
# now open that localhost page
```
