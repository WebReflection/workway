const workway = require('workway');

// export any namespace or even modules
workway(require('os'));
