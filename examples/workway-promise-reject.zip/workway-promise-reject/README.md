# Promise reject from Node.js

This demo shows results when a Promise fails.

```sh
npm install
# now open that localhost page
```
